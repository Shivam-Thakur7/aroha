import sqlite_utils


db = sqlite_utils.Database("fashion.db")


users = db["user"].rows

for user in users:
    print(user)